--ranking wizyt
USE Szpital;

SELECT w_pacjent_id, w_id, w_data_godzina, RANK() OVER (PARTITION BY w_pacjent_id ORDER BY w_data_godzina DESC) AS ranking_wizyty 
FROM dbo.WIZYTA
ORDER BY w_pacjent_id, ranking_wizyty;

--poprzednia wizyta i dni od poprzedniej wizyty
SELECT w_pacjent_id, w_id, w_data_godzina, PoprzedniaWizyta, DATEDIFF(day, PoprzedniaWizyta, w_data_godzina) AS DniOdPoprzedniejWizyty 
FROM 
(
    SELECT 
        w_pacjent_id, 
        w_id, 
        w_data_godzina, 
        LAG(w_data_godzina) OVER (PARTITION BY w_pacjent_id ORDER BY w_data_godzina) AS PoprzedniaWizyta
    FROM dbo.WIZYTA
) AS WizytyLag
ORDER BY w_pacjent_id, w_data_godzina;
