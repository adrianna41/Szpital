--abela logi wizyt
CREATE TABLE dbo.WIZYTY_LOGI (
    log_id INT IDENTITY(1,1) PRIMARY KEY,
    w_id INT NOT NULL,
    stary_status NVARCHAR(20),
    nowy_status NVARCHAR(20),
    stara_data DATETIME,
    nowa_data DATETIME,
    data_modyfikacji DATETIME DEFAULT GETDATE(),
    uzytkownik NVARCHAR(100) DEFAULT SYSTEM_USER
);
GO

--triger: aktualizacja wizyty
CREATE OR ALTER TRIGGER dbo.trg_WizytaUpdateLog
ON dbo.WIZYTA
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.WIZYTY_LOGI (w_id, stary_status, nowy_status, stara_data, nowa_data)
    SELECT 
        i.w_id, 
        d.w_status, 
        i.w_status, 
        d.w_data_godzina, 
        i.w_data_godzina
    FROM inserted i
    JOIN deleted d ON i.w_id = d.w_id
    WHERE ISNULL(i.w_status, '') <> ISNULL(d.w_status, '')
       OR ISNULL(i.w_data_godzina, '1900-01-01') <> ISNULL(d.w_data_godzina, '1900-01-01');
END;