USE Szpital;

INSERT INTO ODDZIAL VALUES
    ('Szpitalny Oddział Ratunkowy'),
    ('Oddział Intensywnej Terapii'),
    ('Izba Przyjęć'),
    ('Oddział Kardiologiczny'),
    ('Oddział Neurologiczny'),
    ('Oddział Pediatryczny'),
    ('Oddział Psychiatryczny'), 
    ('Oddział Onkologiczny'),
    ('Oddział Zakaźny'),
    ('Oddział Pulmonologiczny'), 
    ('Oddział Geriatryczny'),
    ('Oddział Chirurgii Ogólnej'),
    ('Oddział Chirurgii Dziecięcej'),
    ('Oddział Laryngologiczny'),
    ('Oddział Neurochirurgiczny'),
    ('Oddział Okulistyczny'),
    ('Oddział Położniczy'),
    ('Oddział Urologiczny');

INSERT INTO STANOWISKO VALUES
    ('Ordynator', 18500.00),
    ('Lekarz specjalista', 14000.00),
    ('Lekarz rezydent', 8500.00),
    ('Lekarz stażysta', 6000.00),
    ('Pielęgniarka oddziałowa', 9500.00),
    ('Pielęgniarka', 7500.00),
    ('Położna', 7500.00),
    ('Ratownik medyczny', 7000.00),
    ('Diagnosta laboratoryjny', 7200.00),
    ('Technik elektroradiolog', 6800.00),
    ('Fizjoterapeuta', 6500.00),
    ('Psycholog kliniczny', 7000.00),
    ('Dietetyk kliniczny', 6000.00),
    ('Farmaceuta szpitalny', 8000.00),
    ('Opiekun medyczny', 5500.00),
    ('Sanitariusz', 5000.00),
    ('Salowa', 4500.00),
    ('Rejestrator medyczny', 4800.00),
    ('Dyrektor Szpitala', 25000.00),
    ('Dyrektor ds. Medycznych', 22000.00);

INSERT INTO CHOROBA VALUES
    ('Nadciśnienie tętnicze'),
    ('Zawał mięśnia sercowego'),
    ('Niewydolność serca'),
    ('Migotanie przedsionków'),
    ('Udar niedokrwienny mózgu'),
    ('Stwardnienie rozsiane (SM)'),
    ('Padaczka'),
    ('Wstrząśnienie mózgu'),
    ('Zapalenie płuc'),
    ('Przewlekła obturacyjna choroba płuc (POChP)'),
    ('Astma oskrzelowa'),
    ('COVID-19'),
    ('Grypa'),
    ('Ostre zapalenie wyrostka robaczkowego'),
    ('Kamica pęcherzyka żółciowego'),
    ('Choroba wrzodowa żołądka i dwunastnicy'),
    ('Przepuklina pachwinowa'),
    ('Złamanie kości udowej'),
    ('Zwichnięcie stawu barkowego'),
    ('Zerwanie więzadła krzyżowego przedniego (ACL)'),
    ('Nowotwór złośliwy płuca'),
    ('Rak piersi'),
    ('Rak gruczołu krokowego'),
    ('Przewlekła niewydolność nerek'),
    ('Zakażenie układu moczowego (ZUM)'),
    ('Kamica nerkowa'),
    ('Zaburzenia depresyjne'),
    ('Schizofrenia'),
    ('Zaćma'),
    ('Jaskra'),
    ('Przerost migdałków podniebiennych'),
    ('Przewlekłe zapalenie zatok');

INSERT INTO SALA (s_oddzial_id, s_numer, s_rola) VALUES
    (1, 'SOR-01', 'Triage / Kwalifikacja'),
    (1, 'SOR-02', 'Sala reanimacyjna'),
    (1, 'SOR-03', 'Gabinet zabiegowy chirurgiczny'),
    (2, 'OIT-1', 'Sala intensywnej terapii (stanowiska 1-4)'),
    (2, 'OIT-IZO', 'Izolatka OIT'),
    (3, 'IP-01', 'Punkt rejestracji i przyjęć planowych'),
    (4, '101', 'Sala chorych (2-osobowa)'),
    (4, '102', 'Sala Intensywnego Nadzoru Kardiologicznego'),
    (4, 'GAB-EKG', 'Pracownia EKG i UKG (Echo serca)'),
    (5, '201', 'Sala chorych (3-osobowa) - Pododdział Udarowy'),
    (6, '301', 'Sala chorych (niemowlęta)'),
    (6, '302', 'Świetlica / Pokój zabaw dla dzieci'),
    (8, '401', 'Sala Chemioterapii Dziennej'),
    (9, 'IZO-1', 'Izolatka ze śluzą podciśnieniową'),
    (12, 'BL-01', 'Sala operacyjna główna'),
    (12, 'BL-02', 'Sala operacyjna "ostra"'),
    (12, 'POP-1', 'Sala wybudzeń (Post-Anesthesia Care Unit)'),
    (15, 'NCH-BL', 'Sala operacyjna neurochirurgiczna (z mikroskopem)'),
    (17, 'POL-01', 'Sala porodowa rodzinna'),
    (17, 'CC-01', 'Sala Cięć Cesarskich');
GO
CREATE OR ALTER FUNCTION fn_ListaImion() RETURNS TABLE AS RETURN
SELECT * FROM (VALUES 
    (1, 'Jan'), (2, 'Bożydar'), (3, 'Marek'), (4, 'Hamlet'), (5, 'Piotr'), 
    (6, 'Adrian'), (7, 'Tomasz'), (8, 'Emil'), (9, 'Paweł'), (10, 'Jakub'), 
    (11, 'Grzegorz'), (12, 'Tymoteusz'), (13, 'Michał'), (14, 'Kacper'), (15, 'Łukasz'), 
    (16, 'Oskar'), (17, 'Adam'), (18, 'Damian'), (19, 'Rafał'), (20, 'Bartosz'),
    (21, 'Maciej'), (22, 'Krzysztof'), (23, 'Dawid'), (24, 'Wojciech'), (25, 'Mateusz'),
    (26, 'Ryszard'), (27, 'Jerzy'), (28, 'Kamil'), (29, 'Andrzej'), (30, 'Józef'),
    (31, 'Stanisław'), (32, 'Mikołaj'), (33, 'Szymon'), (34, 'Patryk'), (35, 'Sebastian'),
    (36, 'Antoni'), (37, 'Filip'), (38, 'Janusz'), (39, 'Mirosław'), (40, 'Sławomir'),
    (41, 'Henryk'), (42, 'Artur'), (43, 'Waldemar'), (44, 'Mariusz'), (45, 'Dariusz'),
    (46, 'Zbigniew'), (47, 'Krystian'), (48, 'Przemysław'), (49, 'Robert'), (50, 'Igor')
) AS Imiona(ID, Imie);
GO

CREATE OR ALTER FUNCTION fn_ListaNazwisk() RETURNS TABLE AS RETURN
SELECT * FROM (VALUES 
    (1, 'Kowalski'), (2, 'Nowak'), (3, 'Wiśniewski'), (4, 'Wójcik'), (5, 'Kamiński'), 
    (6, 'Lewandowski'), (7, 'Zieliński'), (8, 'Szymański'), (9, 'Woźniak'), (10, 'Dąbrowski'), 
    (11, 'Lis'), (12, 'Król'), (13, 'Górski'), (14, 'Jankowski'), (15, 'Mazur'), 
    (16, 'Kaczmarek'), (17, 'Krawczyk'), (18, 'Piotrowski'), (19, 'Grabowski'), (20, 'Michalski'),
    (21, 'Zając'), (22, 'Wieczorek'), (23, 'Jabłoński'), (24, 'Dudek'), (25, 'Majewski'),
    (26, 'Stępień'), (27, 'Malinowski'), (28, 'Jaworski'), (29, 'Pawlak'), (30, 'Sikora'),
    (31, 'Walczak'), (32, 'Rutkowski'), (33, 'Baran'), (34, 'Michalak'), (35, 'Szewczyk'),
    (36, 'Ostrowski'), (37, 'Tomaszewski'), (38, 'Pietrzak'), (39, 'Zalewski'), (40, 'Wróblewski'),
    (41, 'Marciniak'), (42, 'Jasiński'), (43, 'Zawadzki'), (44, 'Bąk'), (45, 'Jakubowski'),
    (46, 'Sadowski'), (47, 'Włodarczyk'), (48, 'Chmielewski'), (49, 'Borkowski'), (50, 'Sokołowski')
) AS Nazwiska(ID, Nazwisko);
GO

CREATE OR ALTER FUNCTION fn_ListaImionZ() RETURNS TABLE AS RETURN
SELECT * FROM (VALUES 
    (1, 'Joanna'), (2, 'Anna'), (3, 'Mariola'), (4, 'Ewa'), (5, 'Nikola'), 
    (6, 'Katarzyna'), (7, 'Daria'), (8, 'Agnieszka'), (9, 'Małgorzata'), (10, 'Magdalena'), 
    (11, 'Oliwia'), (12, 'Aleksandra'), (13, 'Gabriela'), (14, 'Zofia'), (15, 'Natalia'), 
    (16, 'Barbara'), (17, 'Zuzanna'), (18, 'Maria'), (19, 'Julia'), (20, 'Izabela'),
    (21, 'Krystyna'), (22, 'Halina'), (23, 'Irena'), (24, 'Beata'), (25, 'Dorota'),
    (26, 'Marta'), (27, 'Karolina'), (28, 'Monika'), (29, 'Sylwia'), (30, 'Paulina'),
    (31, 'Weronika'), (32, 'Alicja'), (33, 'Grażyna'), (34, 'Bożena'), (35, 'Teresa'),
    (36, 'Jadwiga'), (37, 'Danuta'), (38, 'Urszula'), (39, 'Kinga'), (40, 'Justyna'),
    (41, 'Edyta'), (42, 'Jolanta'), (43, 'Iwona'), (44, 'Aneta'), (45, 'Kamila'),
    (46, 'Marzena'), (47, 'Renata'), (48, 'Wioletta'), (49, 'Agata'), (50, 'Ewelina')
) AS Imiona(ID, Imie);
GO

CREATE OR ALTER FUNCTION fn_ListaNazwiskZ() RETURNS TABLE AS RETURN
SELECT * FROM (VALUES 
    (1, 'Kowalska'), (2, 'Nowak'), (3, 'Wiśniewska'), (4, 'Wójcik'), (5, 'Kamińska'), 
    (6, 'Lewandowska'), (7, 'Zielińska'), (8, 'Szymańska'), (9, 'Woźniak'), (10, 'Dąbrowska'), 
    (11, 'Lis'), (12, 'Król'), (13, 'Górska'), (14, 'Jankowska'), (15, 'Mazur'), 
    (16, 'Kaczmarek'), (17, 'Krawczyk'), (18, 'Piotrowska'), (19, 'Grabowska'), (20, 'Michalska'),
    (21, 'Zając'), (22, 'Wieczorek'), (23, 'Jabłońska'), (24, 'Dudek'), (25, 'Majewska'),
    (26, 'Stępień'), (27, 'Malinowska'), (28, 'Jaworska'), (29, 'Pawlak'), (30, 'Sikora'),
    (31, 'Walczak'), (32, 'Rutkowska'), (33, 'Baran'), (34, 'Michalak'), (35, 'Szewczyk'),
    (36, 'Ostrowska'), (37, 'Tomaszewska'), (38, 'Pietrzak'), (39, 'Zalewska'), (40, 'Wróblewska'),
    (41, 'Marciniak'), (42, 'Jasińska'), (43, 'Zawadzka'), (44, 'Bąk'), (45, 'Jakubowska'),
    (46, 'Sadowska'), (47, 'Włodarczyk'), (48, 'Chmielewska'), (49, 'Borkowska'), (50, 'Sokołowska')
) AS Nazwiska(ID, Nazwisko);
GO
CREATE OR ALTER PROCEDURE dbo.GenerujPracownikow
    @ile INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @i INT = 1;
    DECLARE @Imie NVARCHAR(50), @Nazwisko NVARCHAR(50);
    DECLARE @StanowiskoID INT, @OddzialID INT;
    DECLARE @Plec BIT; 

    WHILE @i <= @ile
    BEGIN
        BEGIN TRY
            SET @Plec = CASE WHEN RAND(CHECKSUM(NEWID())) > 0.5 THEN 1 ELSE 0 END;

            IF @Plec = 0
            BEGIN
                SELECT TOP 1 @Imie = Imie FROM dbo.fn_ListaImion() ORDER BY NEWID();
                SELECT TOP 1 @Nazwisko = Nazwisko FROM dbo.fn_ListaNazwisk() ORDER BY NEWID();
            END
            ELSE
            BEGIN
                SELECT TOP 1 @Imie = Imie FROM dbo.fn_ListaImionZ() ORDER BY NEWID();
                SELECT TOP 1 @Nazwisko = Nazwisko FROM dbo.fn_ListaNazwiskZ() ORDER BY NEWID();
            END

            SELECT TOP 1 @StanowiskoID = st_id FROM dbo.STANOWISKO ORDER BY NEWID();
            SELECT TOP 1 @OddzialID = od_id FROM dbo.ODDZIAL ORDER BY NEWID();

            INSERT INTO dbo.PRACOWNIK (pr_imie, pr_nazwisko, pr_stanowisko_id, pr_oddzial_id)
            VALUES (@Imie, @Nazwisko, @StanowiskoID, @OddzialID);

        END TRY
        BEGIN CATCH
            PRINT 'Błąd pracownika w iteracji ' + CAST(@i AS NVARCHAR) + ': ' + ERROR_MESSAGE();
        END CATCH

        SET @i += 1;
    END
END;
GO

CREATE OR ALTER PROCEDURE dbo.GenerujPacjentow
    @ile INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @i INT = 1;
    DECLARE @Imie NVARCHAR(50), @Nazwisko NVARCHAR(50);
    DECLARE @Pesel NVARCHAR(11);
    DECLARE @NrTel NVARCHAR(15);
    DECLARE @Adres NVARCHAR(300);
    DECLARE @Plec BIT;

    WHILE @i <= @ile
    BEGIN
        BEGIN TRY
            SET @Plec = CASE WHEN RAND(CHECKSUM(NEWID())) > 0.5 THEN 1 ELSE 0 END;

            IF @Plec = 0
            BEGIN
                SELECT TOP 1 @Imie = Imie FROM dbo.fn_ListaImion() ORDER BY NEWID();
                SELECT TOP 1 @Nazwisko = Nazwisko FROM dbo.fn_ListaNazwisk() ORDER BY NEWID();
            END
            ELSE
            BEGIN
                SELECT TOP 1 @Imie = Imie FROM dbo.fn_ListaImionZ() ORDER BY NEWID();
                SELECT TOP 1 @Nazwisko = Nazwisko FROM dbo.fn_ListaNazwiskZ() ORDER BY NEWID();
            END

            SET @Pesel = CAST(CAST(RAND(CHECKSUM(NEWID())) * 899999 + 100000 AS INT) AS NVARCHAR(6)) + 
                         CAST(CAST(RAND(CHECKSUM(NEWID())) * 89999 + 10000 AS INT) AS NVARCHAR(5));

            
            SET @NrTel = CAST(CAST(RAND(CHECKSUM(NEWID())) * 400 + 500 AS INT) AS NVARCHAR(3)) + '-' +
                         CAST(CAST(RAND(CHECKSUM(NEWID())) * 900 + 100 AS INT) AS NVARCHAR(3)) + '-' +
                         CAST(CAST(RAND(CHECKSUM(NEWID())) * 900 + 100 AS INT) AS NVARCHAR(3));

            SET @Adres = 'ul. Testowa ' + CAST(CAST(RAND(CHECKSUM(NEWID())) * 150 + 1 AS INT) AS NVARCHAR(3)) + ', 90-001 Łódź';

            INSERT INTO dbo.PACJENT (p_imie, p_nazwisko, p_pesel, p_nr_tel, p_adres)
            VALUES (@Imie, @Nazwisko, @Pesel, @NrTel, @Adres);

        END TRY
        BEGIN CATCH
            PRINT 'Błąd pacjenta w iteracji ' + CAST(@i AS NVARCHAR) + ': ' + ERROR_MESSAGE();
        END CATCH

        SET @i += 1;
    END
END;
GO

EXEC dbo.GenerujPracownikow 10;
EXEC dbo.GenerujPacjentow 20;
GO

--- tabela UZYTKOWNIK 
CREATE OR ALTER PROCEDURE dbo.UzupełnijKontaPracownikow
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @pr_id INT, @imie NVARCHAR(50), @nazwisko NVARCHAR(50), @stanowisko NVARCHAR(50);
    DECLARE @login NVARCHAR(50), @u_id INT, @rola NVARCHAR(20);

    DECLARE cur_pracownicy CURSOR FOR 
    SELECT p.pr_id, p.pr_imie, p.pr_nazwisko, s.st_nazwa
    FROM dbo.PRACOWNIK p
    JOIN dbo.STANOWISKO s ON p.pr_stanowisko_id = s.st_id
    WHERE p.pr_uzytkownik_id IS NULL
      AND (s.st_nazwa LIKE 'Lekarz%' 
           OR s.st_nazwa = 'Ordynator' 
           OR s.st_nazwa LIKE 'Dyrektor%');

    OPEN cur_pracownicy;
    FETCH NEXT FROM cur_pracownicy INTO @pr_id, @imie, @nazwisko, @stanowisko;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @login = LOWER(@imie + '.' + @nazwisko);
        
        WHILE EXISTS (SELECT 1 FROM dbo.UZYTKOWNIK WHERE u_login = @login)
        BEGIN
            SET @login = LOWER(@imie + '.' + @nazwisko) + CAST(CAST(RAND(CHECKSUM(NEWID())) * 100 AS INT) AS NVARCHAR(5));
        END

        SET @rola = CASE 
            WHEN @stanowisko LIKE 'Dyrektor%' THEN 'admin'
            ELSE 'lekarz'
        END;

        INSERT INTO dbo.UZYTKOWNIK (u_login, u_haslo_hash, u_rola)
        VALUES (@login, CONVERT(NVARCHAR(255), HASHBYTES('SHA2_256', 'Pracownik123!'), 2), @rola);

        SET @u_id = SCOPE_IDENTITY();

        UPDATE dbo.PRACOWNIK
        SET pr_uzytkownik_id = @u_id
        WHERE pr_id = @pr_id;

        FETCH NEXT FROM cur_pracownicy INTO @pr_id, @imie, @nazwisko, @stanowisko;
    END

    CLOSE cur_pracownicy;
    DEALLOCATE cur_pracownicy;
    PRINT 'Wygenerowano konta wyłącznie dla lekarzy i administratorów.';
END;
GO

EXEC dbo.UzupełnijKontaPracownikow;

--tabele wizyta, recpeta, diagnoza, skierowanie, grafik
INSERT INTO dbo.GRAFIK (g_pracownik_id, g_sala_id, g_start, g_koniec) VALUES
(1, 1, '2026-06-15 08:00:00', '2026-06-15 16:00:00'), 
(8, 7, '2026-06-16 08:00:00', '2026-06-16 16:00:00'), 
(10, 6, '2026-06-17 08:00:00', '2026-06-17 16:00:00'), 
(1, 9, '2026-06-18 08:00:00', '2026-06-18 16:00:00'), 
(8, 3, '2026-06-19 16:00:00', '2026-06-20 00:00:00'), 
(10, 1, '2026-06-20 08:00:00', '2026-06-20 16:00:00'), 
(1, 2, '2026-06-21 08:00:00', '2026-06-21 16:00:00'); 


INSERT INTO dbo.WIZYTA (w_pacjent_id, w_lekarz_id, w_sala_id, w_data_godzina, w_status) VALUES
(1, 1, 9, '2026-06-10 09:30:00', 'zakończona'),
(2, 8, 7, '2026-06-11 11:15:00', 'zakończona'),
(3, 10, 1, '2026-06-12 14:00:00', 'zakończona'),
(4, 1, 6, '2026-06-12 15:30:00', 'zakończona'), 
(5, 8, 3, '2026-06-13 10:00:00', 'zakończona'), 
(6, 10, 1, '2026-06-13 12:45:00', 'zakończona'), 
(7, 1, 9, '2026-06-18 10:45:00', 'umówiona'),   
(8, 8, 7, '2026-06-19 12:00:00', 'umówiona');   

INSERT INTO dbo.DIAGNOZA (dia_wizyta_id, dia_choroba_id, dia_opis) VALUES
(1, 1, 'Pacjentka zgłasza podwyższone ciśnienie od kilku dni. Zalecono leki hipotensyjne i regularną kontrolę.'), 
(2, 9, 'Osłuchowo szmery w płucach, wysoka gorączka. Skierowano na RTG klatki piersiowej i włączono antybiotyk.'), 
(3, 18, 'Stan po upadku ze schodów. Silny ból kończyny dolnej, obrzęk. Założono unieruchomienie tymczasowe.'), 
(4, 12, 'Dodatni wynik testu na COVID-19. Zalecono izolację, leczenie objawowe oraz dużą ilość płynów.'), 
(5, 8, 'Pacjentka po uderzeniu w głowę. Zgłasza zawroty głowy i nudności. Parametry życiowe w normie.'),
(6, 2, 'Silny, piekący ból w klatce piersiowej promieniujący do lewej ręki. EKG wykazuje zmiany niedokrwienne.'); 


INSERT INTO dbo.RECEPTA (r_diagnoza_id, r_leki, r_data_wystawienia) VALUES
(1, 'Bisocard 5mg - 1x dziennie rano', '2026-06-10'),
(1, 'Kaptopril 25mg - podjęzykowo przy skokach ciśnienia', '2026-06-10'), 
(2, 'Amotaks 1g - 2x dziennie przez 7 dni', '2026-06-11'),
(4, 'Paracetamol 500mg doraźnie, Witamina D3 2000j', '2026-06-12'),
(5, 'Ketonal Active 50mg - maksymalnie 3x na dobę przy silnym bólu', '2026-06-13'),
(6, 'Acard 75mg - natychmiast', '2026-06-13'); 

INSERT INTO dbo.SKIEROWANIE (ski_pacjent_id, ski_lekarz_id, ski_do_specjalisty, ski_data_wystawienia) VALUES
(2, 8, 'Pracownia RTG (RTG klatki piersiowej)', '2026-06-11'),    
(3, 10, 'Poradnia Ortopedyczna', '2026-06-12'),                   
(5, 8, 'Poradnia Neurologiczna', '2026-06-13'),                   
(6, 10, 'Oddział Kardiologiczny - Przyjęcie CITO', '2026-06-13'), 
(4, 1, 'Poradnia Pulmonologiczna (Kontrola pocovidowa)', '2026-06-12'), 
(7, 1, 'Pracownia EKG metodą Holtera', '2026-06-14'),             
(8, 8, 'Pracownia Rezonansu Magnetycznego (MRI)', '2026-06-14');  

