USE Szpital;
GO

-- rejestr wizyt
CREATE OR ALTER VIEW dbo.vw_Recepcja_Wizyty
AS
SELECT 
    w.w_id AS IdWizyty,
    w.w_data_godzina AS Termin,
    w.w_status AS StatusWizyty,
    p.p_imie + ' ' + p.p_nazwisko AS Pacjent,
    p.p_pesel AS PeselPacjenta,
    lek.pr_imie + ' ' + lek.pr_nazwisko AS LekarzProwadzacy,
    s.s_numer AS NumerSali
FROM dbo.WIZYTA w
JOIN dbo.PACJENT p ON w.w_pacjent_id = p.p_id
JOIN dbo.PRACOWNIK lek ON w.w_lekarz_id = lek.pr_id
JOIN dbo.SALA s ON w.w_sala_id = s.s_id;
GO

-- Test widoku 1
SELECT * FROM dbo.vw_Recepcja_Wizyty;
GO

--widok 2: pracownicy, stanowiska, pensje, oddział, staż pracy (dane mogą posłużyć do umów generowanych przez dział kadr)
CREATE OR ALTER VIEW dbo.vw_Kadry_Zatrudnienie
AS
SELECT pr.pr_id AS IdPracownika, pr.pr_imie AS Imie, pr.pr_nazwisko AS Nazwisko,st.st_nazwa AS Stanowisko,
    st.st_pensja AS PensjaZasadnicza,od.od_nazwa AS Oddzial, dbo.fn_ObliczStazPracy(pr.pr_data_zatrudnienia) AS StazPracyLata
FROM dbo.PRACOWNIK pr
INNER JOIN dbo.STANOWISKO st ON pr.pr_stanowisko_id = st.st_id
LEFT JOIN dbo.ODDZIAL od ON pr.pr_oddzial_id = od.od_id;
GO

-- test widoku 2
PRINT '--- TEST WIDOKU: Kadry ---';
SELECT * FROM dbo.vw_Kadry_Zatrudnienie;