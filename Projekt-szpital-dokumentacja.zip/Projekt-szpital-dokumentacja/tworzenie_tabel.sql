CREATE DATABASE Szpital;
USE Szpital;

CREATE TABLE ODDZIAL (
    od_id INT IDENTITY(1,1) PRIMARY KEY,
    od_nazwa NVARCHAR(100) NOT NULL
);

CREATE TABLE STANOWISKO (
    st_id INT IDENTITY(1,1) PRIMARY KEY,
    st_nazwa NVARCHAR(50) NOT NULL,
    st_pensja DECIMAL(10, 2)
);

CREATE TABLE CHOROBA (
    ch_id INT IDENTITY(1,1) PRIMARY KEY,
    ch_nazwa NVARCHAR(100) NOT NULL
);

CREATE TABLE SALA (
    s_id INT IDENTITY(1,1) PRIMARY KEY,
    s_oddzial_id INT NOT NULL REFERENCES ODDZIAL(od_id),
    s_numer NVARCHAR(10) NOT NULL,
    s_rola NVARCHAR(50)
);

CREATE TABLE UZYTKOWNIK (
    u_id INT IDENTITY(1,1) PRIMARY KEY,
    u_login NVARCHAR(50) UNIQUE NOT NULL,
    u_haslo_hash NVARCHAR(255) NOT NULL,
    u_rola NVARCHAR(20) NOT NULL CHECK (u_rola IN ('admin', 'lekarz', 'pacjent'))
);

CREATE TABLE PRACOWNIK (
    pr_id INT IDENTITY(1,1) PRIMARY KEY,
    pr_imie NVARCHAR(50) NOT NULL,
    pr_nazwisko NVARCHAR(50) NOT NULL,
    pr_stanowisko_id INT NOT NULL REFERENCES STANOWISKO(st_id),
    pr_oddzial_id INT NOT NULL REFERENCES ODDZIAL(od_id),
    pr_data_zatrudnienia DATE NOT NULL DEFAULT GETDATE(),
    pr_uzytkownik_id INT REFERENCES UZYTKOWNIK(u_id) 
);

CREATE TABLE PACJENT (
    p_id INT IDENTITY(1,1) PRIMARY KEY,
    p_imie NVARCHAR(50) NOT NULL,
    p_nazwisko NVARCHAR(50) NOT NULL,
    p_pesel NVARCHAR(11) UNIQUE NOT NULL,
    p_nr_tel NVARCHAR(15),
    p_adres NVARCHAR(300),
    p_uzytkownik_id INT REFERENCES UZYTKOWNIK(u_id) 
);

CREATE UNIQUE NONCLUSTERED INDEX UQ_Pracownik_Uzytkownik 
ON PRACOWNIK(pr_uzytkownik_id) 
WHERE pr_uzytkownik_id IS NOT NULL;

CREATE UNIQUE NONCLUSTERED INDEX UQ_Pacjent_Uzytkownik 
ON PACJENT(p_uzytkownik_id) 
WHERE p_uzytkownik_id IS NOT NULL;

CREATE TABLE WIZYTA (
    w_id INT IDENTITY(1,1) PRIMARY KEY,
    w_pacjent_id INT NOT NULL REFERENCES PACJENT(p_id),
    w_lekarz_id INT NOT NULL REFERENCES PRACOWNIK(pr_id),
    w_sala_id INT REFERENCES SALA(s_id),
    w_data_godzina DATETIME NOT NULL,
    w_status NVARCHAR(20) DEFAULT 'um�wiona'
);

CREATE TABLE GRAFIK (
    g_id INT IDENTITY(1,1) PRIMARY KEY,
    g_pracownik_id INT NOT NULL REFERENCES PRACOWNIK(pr_id),
    g_sala_id INT NOT NULL REFERENCES SALA(s_id),
    g_start DATETIME NOT NULL,
    g_koniec DATETIME NOT NULL
);

CREATE TABLE SKIEROWANIE (
    ski_id INT IDENTITY(1,1) PRIMARY KEY,
    ski_pacjent_id INT NOT NULL REFERENCES PACJENT(p_id),
    ski_lekarz_id INT NOT NULL REFERENCES PRACOWNIK(pr_id),
    ski_do_specjalisty NVARCHAR(100) NOT NULL,
    ski_data_wystawienia DATE NOT NULL DEFAULT GETDATE()
);

CREATE TABLE DIAGNOZA (
    dia_id INT IDENTITY(1,1) PRIMARY KEY,
    dia_wizyta_id INT NOT NULL REFERENCES WIZYTA(w_id),
    dia_choroba_id INT NOT NULL REFERENCES CHOROBA(ch_id),
    dia_opis NVARCHAR(2500)
);

CREATE TABLE RECEPTA (
    r_id INT IDENTITY(1,1) PRIMARY KEY,
    r_diagnoza_id INT NOT NULL REFERENCES DIAGNOZA(dia_id),
    r_leki NVARCHAR(1300) NOT NULL,
    r_data_wystawienia DATE NOT NULL DEFAULT GETDATE()
);