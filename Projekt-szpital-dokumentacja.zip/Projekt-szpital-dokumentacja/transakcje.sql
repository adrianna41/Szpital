--transakcje
--1
BEGIN TRAN;
PRINT 'Po BEGIN TRAN: ' + CAST(@@TRANCOUNT AS VARCHAR);
INSERT INTO dbo.ODDZIAL (od_nazwa) VALUES ('Kardiologia Dziecięca');
DECLARE @OddzialID INT = SCOPE_IDENTITY();
SAVE TRAN PunktSali;

BEGIN TRAN;
PRINT 'Po BEGIN transakcji wewnętrznej: ' + CAST(@@TRANCOUNT AS VARCHAR);


INSERT INTO dbo.SALA (s_oddzial_id, s_numer, s_rola) 
VALUES (@OddzialID, '101A', 'Sala Operacyjna');
ROLLBACK TRAN PunktSali;
PRINT 'Po ROLLBACK TRAN PunktSali: ' + CAST(@@TRANCOUNT AS VARCHAR);
COMMIT;
COMMIT; 
PRINT 'Po COMMIT: ' + CAST(@@TRANCOUNT AS VARCHAR);

SELECT * FROM dbo.ODDZIAL WHERE od_nazwa = 'Kardiologia Dziecięca';
GO


--2
IF OBJECT_ID('dbo.Bledy') IS NULL
BEGIN
    CREATE TABLE dbo.Bledy (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Tresc NVARCHAR(MAX),
        Czas DATETIME DEFAULT GETDATE()
    );
END;
GO

BEGIN TRY
    BEGIN TRAN;
    INSERT INTO dbo.WIZYTA (w_pacjent_id, w_lekarz_id, w_sala_id, w_data_godzina)
    VALUES (99999, 1, 1, GETDATE());

    COMMIT;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK;

    INSERT INTO dbo.Bledy(Tresc)
    VALUES (ERROR_MESSAGE());
    
    PRINT 'Wystąpił błąd. Szczegóły w tabeli Bledy.';
END CATCH;
GO

