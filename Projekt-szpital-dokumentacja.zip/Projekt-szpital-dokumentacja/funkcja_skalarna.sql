CREATE OR ALTER FUNCTION dbo.fn_LiczbaZakonczonychWizytPacjenta 
(
    @PacjentID INT
)
RETURNS INT
AS
BEGIN
    DECLARE @LiczbaWizyt INT;

    SELECT @LiczbaWizyt = COUNT(w_id)
    FROM dbo.WIZYTA
    WHERE w_pacjent_id = @PacjentID 
      AND LOWER(w_status) = 'zakończona'; 

    RETURN ISNULL(@LiczbaWizyt, 0);
END;
GO
--sprawdzenie działania funkcji
SELECT p_imie AS Imie, p_nazwisko AS Nazwisko, 
dbo.fn_LiczbaZakonczonychWizytPacjenta(p_id) AS LiczbaZakonczonychWizyt
FROM dbo.PACJENT
ORDER BY LiczbaZakonczonychWizyt DESC;
