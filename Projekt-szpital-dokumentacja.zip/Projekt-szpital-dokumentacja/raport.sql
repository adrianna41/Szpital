--Raport:
--XML dokument
SELECT p.p_pesel AS Pesel, p.p_imie AS Imie, p.p_nazwisko AS Nazwisko, w.w_data_godzina AS DataWizyty,w.w_status AS StatusWizyty
FROM dbo.PACJENT p
INNER JOIN dbo.WIZYTA w ON p.p_id = w.w_pacjent_id
FOR XML AUTO, ELEMENTS, ROOT('historia_wizyt');

-- wynenerowanie raportu w pliku JSON
SELECT p.p_pesel AS Pesel, p.p_imie AS Imie, p.p_nazwisko AS Nazwisko,w.w_data_godzina AS DataWizyty,w.w_status AS StatusWizyty
FROM dbo.PACJENT p INNER JOIN dbo.WIZYTA w ON p.p_id = w.w_pacjent_id
FOR JSON AUTO, ROOT('historia_wizyt');