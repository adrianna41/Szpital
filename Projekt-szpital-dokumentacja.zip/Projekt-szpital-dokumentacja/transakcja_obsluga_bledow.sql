-- transakcja: podanie id_choroby, którego nie ma w tabeli CHOROBA, co skutkuje uniemożliwieniem dodania diagnozy
BEGIN TRY
    BEGIN TRANSACTION;
    
    PRINT 'Procedurę zapisu nowej wizyty i jej diagnozy:';
    
    DECLARE @NowaWizytaId INT;
    
    INSERT INTO dbo.WIZYTA (w_pacjent_id, w_lekarz_id, w_sala_id, w_data_godzina, w_status)
    VALUES (1, 1, 1, GETDATE(), 'zakończona');
    
    SET @NowaWizytaId = SCOPE_IDENTITY();
    PRINT 'Pomyślnie utworzono wizytę nr ' + CAST(@NowaWizytaId AS NVARCHAR) + '. Próbuję dodać diagnozę...';

    INSERT INTO dbo.DIAGNOZA (dia_wizyta_id, dia_choroba_id, dia_opis)
    VALUES (@NowaWizytaId, 99999, 'Pacjent ma rzadką chorobę spoza słownika.');
    COMMIT TRANSACTION;
    PRINT 'Operacja zakończona pełnym sukcesem.';

END TRY
BEGIN CATCH
    PRINT 'UWAGA: System napotkał błąd podczas dodawania danych!';
    IF @@TRANCOUNT > 0
    BEGIN
        ROLLBACK TRANSACTION;
        PRINT 'Wykryto otwartą transakcję (@@TRANCOUNT > 0). Wykonano ROLLBACK - wizyta została całkowicie wycofana z bazy.';
    END

    DECLARE @Numer INT = ERROR_NUMBER();
    DECLARE @Wiadomosc NVARCHAR(2048) = ERROR_MESSAGE();

    IF @Numer = 547
    BEGIN
        RAISERROR ('BŁĄD BIZNESOWY: Próba przypisania nieistniejącej choroby! Skontaktuj się z administratorem słownika chorób.', 16, 1);
        DECLARE @CustomThrowMsg NVARCHAR(2048) = 'BŁĄD KRYTYCZNY BAZY: ' + @Wiadomosc;
        THROW 50001, @CustomThrowMsg, 1; 
    END
    ELSE
    BEGIN
        THROW;
    END

END CATCH;