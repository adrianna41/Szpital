USE Szpital;
GO

--tabele pomocnicze
IF OBJECT_ID('dbo.PensjaAudit', 'U') IS NOT NULL DROP TABLE dbo.PensjaAudit;
CREATE TABLE dbo.PensjaAudit (
    AuditID INT IDENTITY PRIMARY KEY,
    StanowiskoID INT NOT NULL,
    OldPensja MONEY NULL,
    NewPensja MONEY NULL,
    ChangeDate DATETIME NOT NULL DEFAULT GETDATE()
);
 
IF OBJECT_ID('dbo.PacjentAudit', 'U') IS NOT NULL DROP TABLE dbo.PacjentAudit;
CREATE TABLE dbo.PacjentAudit (
    AuditID INT IDENTITY PRIMARY KEY,
    PacjentID INT NOT NULL,
    ChangedMessage NVARCHAR(200) NOT NULL,
    ChangeDate DATETIME NOT NULL DEFAULT GETDATE()
);
 
IF OBJECT_ID('dbo.DDLAudit_Klinika', 'U') IS NOT NULL DROP TABLE dbo.DDLAudit_Klinika;
CREATE TABLE dbo.DDLAudit_Klinika (
    AuditID INT IDENTITY PRIMARY KEY,
    EventType NVARCHAR(100) NOT NULL,
    ObjectName NVARCHAR(256) NULL,
    CommandText NVARCHAR(MAX) NULL,
    EventDate DATETIME NOT NULL DEFAULT GETDATE()
);
GO

--triger 1: aktualizacja pensji
CREATE OR ALTER TRIGGER trg_StanowiskaPensjaAudit
ON dbo.STANOWISKO
AFTER UPDATE
AS
BEGIN
    IF (ROWCOUNT_BIG() = 0) RETURN;
    IF UPDATE(st_pensja)
    BEGIN
        INSERT INTO dbo.PensjaAudit (StanowiskoID, OldPensja, NewPensja)
        SELECT d.st_id, d.st_pensja, i.st_pensja
        FROM inserted i
        JOIN deleted d ON i.st_id = d.st_id
        WHERE ISNULL(i.st_pensja, 0) <> ISNULL(d.st_pensja, 0);
    END
END;
GO
 
PRINT 'test 1';
UPDATE dbo.STANOWISKO SET st_pensja = st_pensja + 500 WHERE st_id = 1;
SELECT * FROM dbo.PensjaAudit ORDER BY ChangeDate DESC;
GO

--triger 2: zwraca, które kolumny zostały zaktualizowane
CREATE OR ALTER TRIGGER trg_PacjentColumnsAudit
ON dbo.PACJENT
AFTER UPDATE
AS
BEGIN
    IF (ROWCOUNT_BIG() = 0) RETURN; 
    DECLARE @mask VARBINARY(128) = COLUMNS_UPDATED();
 
    INSERT INTO dbo.PacjentAudit (PacjentID, ChangedMessage)
    SELECT i.p_id, 'Zmodyfikowano podstawowe dane pacjenta (maska wykryła ruch)'
    FROM inserted i
    WHERE SUBSTRING(@mask, 1, 1) <> 0;
END;
GO
 
PRINT 'test 2:';
UPDATE dbo.PACJENT SET p_imie = 'Janusz' WHERE p_id = 1;
SELECT * FROM dbo.PacjentAudit ORDER BY ChangeDate DESC;
GO
 
--triger 3: zabezpieczenie bazy przed zapętlonymi aktualizacjami
CREATE OR ALTER TRIGGER trg_StanowiskaPensjaCorrection
ON dbo.STANOWISKO
AFTER UPDATE
AS
BEGIN
    IF (ROWCOUNT_BIG() = 0) RETURN;
    IF TRIGGER_NESTLEVEL() > 1 RETURN;
    UPDATE dbo.STANOWISKO
    SET st_pensja = 4300
    WHERE st_id IN (SELECT st_id FROM inserted) AND st_pensja < 4300;
END;
GO
 
PRINT 'test 3';
UPDATE dbo.STANOWISKO SET st_pensja = 2000 WHERE st_id = 2;
SELECT st_id, st_nazwa, st_pensja FROM dbo.STANOWISKO WHERE st_id = 2;
GO
 
--triger 4: monitorowanie 
CREATE OR ALTER TRIGGER trg_DDL_Klinika_Audit
ON DATABASE
AFTER CREATE_TABLE
AS
BEGIN
    DECLARE @data XML = EVENTDATA();
 
    INSERT INTO dbo.DDLAudit_Klinika (EventType, ObjectName, CommandText)
    VALUES (
        @data.value('(/EVENT_INSTANCE/EventType)[1]', 'NVARCHAR(100)'),
        @data.value('(/EVENT_INSTANCE/ObjectName)[1]', 'NVARCHAR(256)'),
        @data.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]', 'NVARCHAR(MAX)')
    );
END;
GO
 
PRINT 'test 4:';
CREATE TABLE dbo.TestowaTabelaKliniki (ID INT PRIMARY KEY);
SELECT * FROM dbo.DDLAudit_Klinika ORDER BY EventDate DESC;
DROP TABLE dbo.TestowaTabelaKliniki;
GO

-- triger 5: błąd ujemnej pensji.
CREATE OR ALTER TRIGGER trg_StanowiskaInsertValidation
ON dbo.STANOWISKO
INSTEAD OF INSERT
AS
BEGIN
    IF (ROWCOUNT_BIG() = 0) RETURN;
 
    IF EXISTS (SELECT 1 FROM inserted WHERE st_pensja < 0)
    BEGIN
        THROW 50010, 'Pensja dla stanowiska nie moze byc ujemna.', 1;
    END
 
    INSERT INTO dbo.STANOWISKO (st_nazwa, st_pensja)
    SELECT st_nazwa, st_pensja FROM inserted;
END;
GO
 
PRINT 'Test 5';
BEGIN TRY
    INSERT INTO dbo.STANOWISKO (st_nazwa, st_pensja) VALUES ('Praktykant', -500);
END TRY
BEGIN CATCH
    PRINT 'Blad (oczekiwany): ' + ERROR_MESSAGE();
END CATCH;
GO
 

-- triger 6: sprawdzenie poprawność wprowadzanych dat (nie można podać daty z przeszłości).

CREATE OR ALTER TRIGGER trg_WizytyValidation
ON dbo.WIZYTA
INSTEAD OF INSERT
AS
BEGIN
    IF (ROWCOUNT_BIG() = 0) RETURN;
 
    IF EXISTS (SELECT 1 FROM inserted WHERE w_data_godzina < GETDATE())
    BEGIN
        THROW 50011, 'Nie mozna zaplanowac wizyty w czasie, ktory juz minal.', 1;
    END
 
    INSERT INTO dbo.WIZYTA (w_pacjent_id, w_lekarz_id, w_sala_id, w_data_godzina, w_status)
    SELECT w_pacjent_id, w_lekarz_id, w_sala_id, w_data_godzina, w_status FROM inserted;
END;
GO
 
PRINT 'test 6:';
BEGIN TRY
    INSERT INTO dbo.WIZYTA (w_pacjent_id, w_lekarz_id, w_sala_id, w_data_godzina, w_status)
    VALUES (1, 1, 1, '2020-01-01 10:00', 'umówiona');
END TRY
BEGIN CATCH
    PRINT 'Blad (oczekiwany): ' + ERROR_MESSAGE();
END CATCH;
GO
 
--triger 7: Blokada konkretnej operacji: blokuje możliwość zmiany konkretnej kw_pacjent_id w istniejącym rekordzie
CREATE OR ALTER TRIGGER trg_BlockWizytaPatientChange
ON dbo.WIZYTA
AFTER UPDATE
AS
BEGIN
    IF (ROWCOUNT_BIG() = 0) RETURN;
 
    IF UPDATE(w_pacjent_id)
    BEGIN
        THROW 50012, 'Zmiana przypisanego pacjenta dla istniejacej wizyty jest zabroniona.', 1;
    END
END;
GO
 
PRINT 'Test zadanie 7 - Blokada UPDATE';
BEGIN TRY
    UPDATE dbo.WIZYTA SET w_pacjent_id = 5 WHERE w_id = 1;
END TRY
BEGIN CATCH
    PRINT 'Blad (oczekiwany): ' + ERROR_MESSAGE();
END CATCH;
GO

--triger 8 - walidacja recepty
CREATE OR ALTER TRIGGER trg_ReceptyComplexControl
ON dbo.RECEPTA
INSTEAD OF INSERT
AS
BEGIN
    IF (ROWCOUNT_BIG() = 0) RETURN;
 
    IF EXISTS (SELECT 1 FROM inserted WHERE r_leki IS NULL OR LTRIM(RTRIM(r_leki)) = '')
        THROW 50020, 'Pole lekow na recepcie nie moze byc puste.', 1;
 
    IF EXISTS (
        SELECT 1 FROM inserted i
        LEFT JOIN dbo.DIAGNOZA d ON i.r_diagnoza_id = d.dia_id
        WHERE d.dia_id IS NULL
    )
        THROW 50021, 'Na recepcie wskazano nieistniejaca diagnoze.', 1;
 
    IF EXISTS (SELECT 1 FROM inserted WHERE r_data_wystawienia > GETDATE())
        THROW 50022, 'Data wystawienia recepty nie moze byc z przyszlosci.', 1;
 
    INSERT INTO dbo.RECEPTA (r_diagnoza_id, r_leki, r_data_wystawienia)
    SELECT r_diagnoza_id, r_leki, r_data_wystawienia FROM inserted;
END;
GO
 
PRINT 'Test 8 - walidacja recepty';
 
BEGIN TRY
    INSERT INTO dbo.RECEPTA (r_diagnoza_id, r_leki, r_data_wystawienia) VALUES (1, '', GETDATE());
END TRY
BEGIN CATCH PRINT 'Blad (oczekiwany - brak lekow): ' + ERROR_MESSAGE(); END CATCH;
 
BEGIN TRY
    INSERT INTO dbo.RECEPTA (r_diagnoza_id, r_leki, r_data_wystawienia) VALUES (1, 'Lek X', '2030-01-01');
END TRY
BEGIN CATCH PRINT 'Blad (oczekiwany - bledna data): ' + ERROR_MESSAGE(); END CATCH;
GO