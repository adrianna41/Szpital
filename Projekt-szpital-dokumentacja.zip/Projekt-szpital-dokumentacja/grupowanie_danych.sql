--Analiza obłożenia placówki w czasie.

SELECT 
    YEAR(w.w_data_godzina) AS Rok,
    MONTH(w.w_data_godzina) AS MiesiacNumer,
    COUNT(w.w_id) AS LiczbaWizyt,
    CASE 
        WHEN MONTH(w.w_data_godzina) = 1 THEN 'styczeń'
        WHEN MONTH(w.w_data_godzina) = 2 THEN 'luty'
        WHEN MONTH(w.w_data_godzina) = 3 THEN 'marzec'
        WHEN MONTH(w.w_data_godzina) = 4 THEN 'kwiecień'
        WHEN MONTH(w.w_data_godzina) = 5 THEN 'maj'
        WHEN MONTH(w.w_data_godzina) = 6 THEN 'czerwiec'
        WHEN MONTH(w.w_data_godzina) = 7 THEN 'lipiec'
        WHEN MONTH(w.w_data_godzina) = 8 THEN 'sierpień'
        WHEN MONTH(w.w_data_godzina) = 9 THEN 'wrzesień'
        WHEN MONTH(w.w_data_godzina) = 10 THEN 'październik'
        WHEN MONTH(w.w_data_godzina) = 11 THEN 'listopad'
        WHEN MONTH(w.w_data_godzina) = 12 THEN 'grudzień'
    END AS MiesiacNazwa
FROM dbo.WIZYTA w
GROUP BY YEAR(w.w_data_godzina), MONTH(w.w_data_godzina);