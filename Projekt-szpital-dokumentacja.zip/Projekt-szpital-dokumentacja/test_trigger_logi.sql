USE Szpital;
GO

PRINT '--- TEST 1: Sprawdzenie stanu początkowego ---';
SELECT * FROM dbo.WIZYTY_LOGI;


PRINT '--- TEST 2: Zmiana statusu wizyty (z umówiona na zakończona) ---';
UPDATE dbo.WIZYTA 
SET w_status = 'zakończona' 
WHERE w_id = 4;


PRINT '--- TEST 3: Zmiana daty wizyty o godzinę do przodu ---';
UPDATE dbo.WIZYTA 
SET w_data_godzina = DATEADD(HOUR, 1, w_data_godzina) 
WHERE w_id = 4;


PRINT '--- TEST 4: Próba "pustego" update (zapisanie tego samego statusu) ---';

UPDATE dbo.WIZYTA 
SET w_status = 'zakończona' 
WHERE w_id = 4;


PRINT 'Sprawdzenie końcowej zawartości tabeli logów';
SELECT 
    log_id, 
    w_id, 
    stary_status, 
    nowy_status, 
    CONVERT(VARCHAR(5), stara_data, 108) AS stara_godz,
    CONVERT(VARCHAR(5), nowa_data, 108) AS nowa_godz,
    data_modyfikacji, 
    uzytkownik 
FROM dbo.WIZYTY_LOGI;
GO